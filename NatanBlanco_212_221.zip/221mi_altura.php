<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Natan Blanco">
    <title>Masculino - Femenino</title>
</head>
<body>
    <?php
    //Modifica el ejercicio anterior para que enviado un nombre vía URL me indique mi altura y si está por encima o por debajo de la media (muestra la media).
    $personas = [
        'Juan' => 1.75,
        'Ana' => 1.68,
        'Carlos' => 1.80,
        'Natan' => 1.60,
        'Luis' => 1.85
    ];
    
    $totalAltura = array_sum($personas);
    
    echo "<table border='1'>";
    echo "<thead>";
    echo "<tr><th>Nombre</th><th>Altura (m)</th></tr>";
    echo "</thead>";
    echo "<tbody>";
    
    foreach ($personas as $nombre => $altura) {
        echo "<tr>";
        echo "<td>$nombre</td>";
        echo "<td>$altura</td>";
        echo "</tr>";
    }
    
    echo "</tbody>";
    
    echo "<tfoot>";
    echo "<tr><th>Altura media</th><th>" . number_format($totalAltura / count($personas), 2) . "</th></tr>";
    echo "</tfoot>";
    
    echo "</table>";
    
    if (isset($_GET['nombre']) and array_key_exists($_GET['nombre'], $personas)) {
        $alturaPersona = $personas[$nombreBuscado];
        
        if ($alturaPersona > $alturaMedia) {
            $mensaje = "Estás por encima de la altura media.";
        } elseif ($alturaPersona < $alturaMedia) {
            $mensaje = "Estás por debajo de la altura media.";
        } else {
            $mensaje = "Tienes exactamente la altura media.";
        }
    
        // Mostrar la altura de la persona y el mensaje comparativo
        echo "<p><strong>$nombreBuscado</strong>, tu altura es <strong>$alturaPersona m</strong>.</p>";
        echo "<p>$mensaje La altura media es <strong>" . number_format($alturaMedia, 2) . "m</strong>.</p>";
    }
?>
</body>
</html>