<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Natan Blanco">
    <title>Numeros aleatorios</title>
</head>
<body>
    <?php
    //Genera un array aleatorio de 33 elementos con números comprendidos entre el 0 y 100 y calcula: El mayor, el menor y la media.
    $listaNumeros = [];
    //Generamos la lista de números aleatorios
    for ($i=0; $i < 33; $i++) { 
        $numero = rand(0, 100);
        array_push($listaNumeros, $numero);
    }
    //Calculamos el número mayor
    $mayor = $listaNumeros[0];
    for ($i=0; $i < count($listaNumeros); $i++) { 
        if ($mayor < $listaNumeros[$i]) {
            $mayor = $listaNumeros[$i];
        }
    }
    //Calculamos el número menor
    $menor = $listaNumeros[0];
    for ($i=0; $i < count($listaNumeros); $i++) { 
        if ($menor > $listaNumeros[$i]) {
            $menor = $listaNumeros[$i];
        }
    }
    //Calculamos la media
    $contador = 0;
    for ($i=0; $i < count($listaNumeros); $i++) { 
        $contador += $listaNumeros[$i];
    }
    $media = $contador / count($listaNumeros);
    //Mostramos los resultados
    echo "<ul>";
    echo "<li>El número mayor es: $mayor</li>";
    echo "<li>El número menor es: $menor</li>";
    echo "<li>La media es: $media</li><br><br>";
    echo "</ul>";

    //Mostramos la lista para comprobar que está bien
    foreach ($listaNumeros as $numero){
        echo "<li>$numero</li>";
    }
    ?>
</body>
</html>