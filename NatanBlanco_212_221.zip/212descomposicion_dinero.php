<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Natan Blanco">
    <title>Descomposicion dinero</title>
</head>
<body>
    <?php
    //A partir de una cantidad de dinero, mostrar su descomposición en billetes (500, 200, 100, 50, 20, 10, 5) y monedas (2, 1), para que el número de elementos sea mínimo (no se muestra si no hay).
    $dinero = 124125;
    $billetes = [500, 200, 100, 50, 20, 10, 5, 2, 1];
    $billeteFraccionado = [];

    for ($i=0; $i < count($billetes); $i++) { 
        if ($dinero >= $billetes[$i]) {
            $dinero = $dinero - $billetes[$i];
            array_push($billeteFraccionado, $billetes[$i]);
            $i--;
        }
    }
    foreach ($billeteFraccionado as $mostrarBilletes) {
        echo "$mostrarBilletes -";
    }
    ?>
</body>
</html>