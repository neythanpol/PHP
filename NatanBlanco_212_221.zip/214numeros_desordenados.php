<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Natan Blanco">
    <title>Números aleatorios</title>
</head>
<body>
    <?php
    //Escribe un programa que muestre los números pares del 0 al 50 (dentro de una lista desordenada). Modifica el programa para que le demos el valor máximo por URL.
    //Damos el valor máximo por URL
    $maximo = $_GET['numero'];

    //Comprobamos que el valor es mayor a 0
    if ($maximo >= 0) {
        $listaNumeros = [];
    for ($i=0; $i <= $maximo; $i++) {
        //Insertamos los números pares en una lista vacía
        if ($i % 2 == 0) {
            array_push($listaNumeros, $i);
        }
    }
    //Desordenamos la lista
    shuffle($listaNumeros);
    //Mostramos la lista desordenada
    echo "<ul>";
    foreach ($listaNumeros as $numero){
        echo "<li>$numero</li>";
    }
    echo "</ul>";
    //Si el valor es menor de 0 se mostraré un mensaje de que debe ser mayor o igual a 0
    }else{
        echo "El valor máximo debe ser mayor o igual a 0";
    }
    ?>
</body>
</html>