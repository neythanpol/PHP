<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Natan Blanco">
    <title>Pinta tabla</title>
</head>
<body>
    <table>
        <?php
        $numero = 8;
        echo "<thead><th>Lista</th></thead>";
        for ($i=0; $i < $numero; $i++) { 
            echo "<th>";
            for ($j=0; $j < $numero; $j++) { 
                echo "<td>($i, $j)</td>";
            }
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>