<?php
session_start();
require_once("../modelo/producto.php");

// Inicializar el carrito si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

// Obtener la lista de productos (esto puede venir de una base de datos o estar definido en el código)
$productos = [
    new Producto("Producto 1", 10.0),
    new Producto("Producto 2", 20.0),
    new Producto("Producto 3", 30.0),
];

// Manejar la acción de agregar al carrito
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['agregar'])) {
    $indice = $_POST['indice'];
    if (isset($productos[$indice])) {
        $producto_serializado = serialize($productos[$indice]);
        if (isset($_SESSION['carrito'][$producto_serializado])) {
            $_SESSION['carrito'][$producto_serializado]++;
        } else {
            $_SESSION['carrito'][$producto_serializado] = 1;
        }
    }
    header('Location: ../vista/productos.php');
    exit();
}

// Manejar la acción de eliminar un producto del carrito
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['eliminar'])) {
    $indice = $_POST['indice'];
    $producto_serializado = array_keys($_SESSION['carrito'])[$indice];
    if (isset($_SESSION['carrito'][$producto_serializado])) {
        if ($_SESSION['carrito'][$producto_serializado] > 1) {
            $_SESSION['carrito'][$producto_serializado]--;
        } else {
            unset($_SESSION['carrito'][$producto_serializado]);
        }
    }
    header('Location: ../vista/carrito.php');
    exit();
}

// Manejar la acción de vaciar el carrito
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['vaciar'])) {
    $_SESSION['carrito'] = [];
    header('Location: ../vista/carrito.php');
    exit();
}

// Guardar la sesión en cookies
setcookie('carrito', serialize($_SESSION['carrito']), time() + (86400 * 30), "/"); // 86400 = 1 día
?>