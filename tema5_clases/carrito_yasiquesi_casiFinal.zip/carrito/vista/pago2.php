<?php
session_start();
require_once("../modelo/Producto.php");

// Vaciar el carrito después de completar el pago simulado
if (isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];

    // Eliminar la cookie del carrito
    setcookie('carrito', '', time() - 3600, "/");

    $pago_completado = true;
} else {
    $pago_completado = false;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Realizar Pago de Productos</title>
    <link rel="stylesheet" href="../bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h1>Realizar Pago de Productos</h1>
            </div>
            <div class="card-body">
                <?php if ($pago_completado): ?>
                    <div class="alert alert-success" role="alert">
                        Pago completado. El carrito ha sido vaciado.
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning" role="alert">
                        No hay productos en el carrito para realizar el pago.
                    </div>
                <?php endif; ?>
                <div id="simulated-paypal-button-container" class="text-center mt-4">
                    <button class="btn btn-primary" id="fake-paypal-button">Pagar con PayPal</button>
                </div>
            </div>
            <div class="card-footer text-center">
                <p><a href="productos.php" class="btn btn-secondary mt-3">Volver a la lista de productos</a></p>
            </div>
        </div>
    </div>
    <script>
        document.getElementById('fake-paypal-button').addEventListener('click', function() {
            // Simular el proceso de pago
            alert('Pago completado con éxito.');
            // Vaciar el carrito y redireccionar al finalizar el pago
            window.location.href = "realizar_pago.php";
        });
    </script>
    <script src="../bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

