<?php
    // CONDICIONALES

    // Condicionales simples
    $edad = 18;
    if ($edad === 18) {
        echo "Puedes pasar";
    }
    if ($edad !== 18) {
        echo "Acceso denegado";
    }

    // Condicionales compuestas
    if ($edad === 18) {
        echo "Puedes pasar";
    } else {
        echo "Acceso denegado";
    }
    
    // Condicionales múltiples
    $dias = "Lunes";
    switch ($dias) {
        case 'Lunes':
            echo "Día laboral";
            break;
        case 'Martes':
            echo "Día laboral";
            break;
        case 'Miércoles':
            echo "Día laboral";
            break;
        case 'Jueves':
            echo "Día laboral";
            break;
        case 'Viernes':
            echo "Día laboral";
            break;
        case 'Sábado':
            echo "Día no laboral";
            break;
        case 'Domingo':
            echo "Día festivo";
            break;
        default:
            # code...
            break;
    }

    // Operador ternario
    $mayoriaEdad = ($edad >= 18) ? "Es mayor de edad" : "Es menor de edad";
    echo $mayoriaEdad;
?>