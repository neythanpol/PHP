<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Natan Blanco">
    <title>Alturas</title>
    <style>
        table, th, td{
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
        th{
            background-color: aqua;
        }
    </style>
</head>
<body>
    <?php
    //Mediante un array asociativo, almacena el nombre y la altura de 5 personas (nombre => altura). Posteriormente, recorre el array y muéstralo en una tabla HTML. Finalmente añade una última fila a la tabla con la altura media.
    $personas = [
        'Juan' => 1.75,
        'Ana' => 1.62,
        'Carlos' => 1.81,
        'Natan' => 1.68,
        'Luis' => 1.85
    ];
    
    $totalAltura = array_sum($personas);
    $totalAlturaMedia = $totalAltura / count($personas);
    
    echo "<table>";
    echo "<thead>";
    echo "<tr><th>Nombre</th><th>Altura (m)</th></tr>";
    echo "</thead>";
    echo "<tbody>";
    
    foreach ($personas as $nombre => $altura) {
        echo "<tr>";
        echo "<td>$nombre</td>";
        echo "<td>$altura</td>";
        echo "</tr>";
    }
    
    echo "</tbody>";
    
    echo "<tfoot>";
    echo "<tr><th>Altura media</th><th>".$totalAlturaMedia."m</th></tr>";
    echo "</tfoot>";
    
    echo "</table>";
    ?>
</body>
</html>