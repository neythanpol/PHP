<?php
    /* declaración de variables */
    $entero = 4; // tipo integer
    echo 'La variable $entero contiene '.$entero." y es de tipo ".gettype($entero)."\n";
    echo "<br>En el texto anterior, que es un ejemplo de un ajercicio anterior, vemos como con comillas simples, al escribir la variable, no nos da el resultado de la variable.";
    echo "<br>Sin embargo, con comillas dobles, sí: $entero";

    //Variables superglobales
    echo 'Las variables globales son: $GLOBALS, $_SERVER, $_GET, $_POST, $_FILES, $_COOKIE, $_SESSION, $_REQUEST y $_ENV'//Todas las variables superglobales
    
?>