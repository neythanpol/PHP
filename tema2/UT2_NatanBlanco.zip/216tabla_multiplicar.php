<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Natan Blanco">
    <title>Tabla de multiplicar</title>
</head>
<body>
    <?php
    //Muestra dentro de una tabla HTML la tabla de multiplicar del número que reciba como parámetro por URL. Utiliza <thead> con sus respectivos <th> y <tbody> para dibujar la tabla.
    $valor = $_GET['numero'];
    // Comenzamos a dibujar la tabla
    echo "<h1>Tabla de multiplicar del número $valor</h1>";
    echo "<table>";
    echo "<thead>";
    echo "<tr><th>Multiplicación</th><th>Resultado</th></tr>";
    echo "</thead>";
    echo "<tbody>";

    // Generar las filas con las multiplicaciones del 1 al 10
    for ($i = 1; $i <= 10; $i++) {
        $resultado = $valor * $i;
        echo "<tr><td>$valor x $i</td><td>$resultado</td></tr>";
    }
    echo "</tbody>";
    echo "</table>";
    ?>
</body>
</html>