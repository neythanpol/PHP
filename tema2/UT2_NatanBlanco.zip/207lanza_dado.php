<?php 
    $oportunidad = 0;
    $salir = false;
    do {
        $dado = rand(1, 6);
        echo "Tirando el dado...";
        echo "ha salido un ".$dado.".<br>";
        if ($dado == 5) {
            $salir = true;
        }
        $oportunidad++;
    } while ($oportunidad < 10 && !$salir); // Sale del bucle ya sea cuando el número de oportunidades pase de 10 o saque un 5
    
    if ($oportunidad < 10) {
        echo "Se ha logrado salir en la oportunidad número ".$oportunidad;
    }else{
        echo "No se ha logrado sacar un 5 en las 10 oportunidades";
    }
?>