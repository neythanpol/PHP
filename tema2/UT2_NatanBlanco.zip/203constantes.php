<?php
    define("PI", 3.1416);
    const IVA = 0.21;
    echo PI, " ", IVA;