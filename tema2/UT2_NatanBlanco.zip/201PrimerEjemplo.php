<!DOCTYPE html>
<html>
<head>
    <title>Hola mundo</title>
</head>
<body>
    <?php echo "Hola mundo 1";
    //Primera forma para mostrar en PHP
    ?>
    <br>
    <?php print "Hola mundo 2";
    #Segunda forma para mostrar en PHP
    ?>
    <br>
    <?= "Hola mundo 3";
    /*Tercera forma para mostrar en PHP
    Todas hacen lo mismo*/
    ?>
</body>
</html>