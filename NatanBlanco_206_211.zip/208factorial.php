<?php
    $num = 0; // Cambiar este valor por cualquier otro valor positivo
    $resultado = 1;
    if ($num === 0) {
        $resultado  = 1;
    } else if ($num < 0) {
        echo "No existe";
        return;
    }
    for ($i = 1; $i<=$num; $i++) {
        $resultado*=$i;
    }
    echo $resultado;
?>