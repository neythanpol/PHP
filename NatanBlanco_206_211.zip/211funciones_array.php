<?php
    $ciudades = ["Madrid", "Barcelona", "Valencia", "Sevilla", "Bilbao"];

    print_r($ciudades);// Muestra el contenido de todo el array
    echo "<br><br>";
    foreach ($ciudades as $ciudad) {
        echo "$ciudad <br>";// Imprime cada ciudad en una nueva línea
    }

    var_dump($ciudades);// Muestra el contenido del elemento recibido

    echo "<br><br>";

    if (in_array("Barcelona", $ciudades)) {// Averigua si $elemento está en el $array
        echo "Barcelona está en la lista de ciudades";
    }

    $eliminada1 = array_pop($ciudades);// array_pop elimina el último elemento (Bilbao)
    print_r($ciudades);
    echo "<br><br>";

    $eliminada2 = array_shift($ciudades);// array_shift elimina el primer elemento (Madrid)
    print_r($ciudades);
    echo "<br><br>";

    array_push($ciudades, $eliminada1);// array_push agrega un elemento al final del array (Bilbao)
    print_r($ciudades);
    echo "<br><br>";

    $precios = [
        "Coche" => 15000,
        "Ordenador" => 1000,
        "Bicicleta" => 500,
        "Televisor" => 400
    ];

    $nombresProductos = array_keys($precios);// Devuelve las claves del $array asociativo
    print_r($nombresProductos);
    echo "<br><br>";

    $tam = count($precios);// Devuelve el tamaño del array
    echo "El tamaño del array es de $tam<br>";

    sort($nombresProductos);// Ordena los elementos del array
    print_r($nombresProductos);
    echo "Ordenado alfabéticamente<br>";

    asort($precios);// Ordena los elementos por elementos de la asociación manteniendo índice
    print_r($precios);
    echo "Ordenado por precios<br><br>";

    if (isset($nombresProductos[1])) {// Indica si existe/tiene valor elemento dentro del array
        unset($nombresProductos[1]);// Elimina el elemento del array
    }
    print_r($nombresProductos);
    echo "<br><br>";

    $descuento = array_slice($precios, 1, 2);// Extrae un array de tamaño num_valores desde la posición clave
    print_r($descuento);
    echo "<br><br>";

    $resultado = array_merge($nombresProductos, $descuento, $ciudades);// Crea un nueno array como unión con claves numéricas
    print_r($resultado);
?>
