<!DOCTYPE html>
<html>
    <head>
        <title>Hola mundo</title>
    </head>
    <body>
    <?php
        echo "Hola mundo"; //Primera forma de escribir texto en PHP.
    ?>
    <br>
    <?php 
        print("Hola mundo"); //Segunda forma de escribir texto en PHP.
    ?>
    <br>
    <?= 
        "Hola mundo" //Tercera forma.
    ?>
    </body>
</html>