<?php
    /* declaración de variables */
    $entero = 4; // tipo integer
    echo 'La variable $entero contiene '.$entero." y es de tipo ".gettype($entero)."\n";
    $numero = 4.5;   // tipo coma flotante
    echo 'La variable $numero contiene '.$numero." y es de tipo ".gettype($numero)."\n";
    $cadena = "cadena"; // tipo cadena de caracteres
    echo 'La variable $cadena contiene '.$cadena." y es de tipo ".gettype($cadena)."\n";
    $bool = true; //tipo booleano
    echo 'La variable $bool contiene '.$bool." y es de tipo ".gettype($bool)."\n";
    /* cambio de tipo de una variable */
    $a = 5; // entero
    echo gettype($a); // imprime el tipo de dato de a
    echo "\n";
    $a = "Hola"; // cambia a cadena     
    echo gettype($a); // se comprueba que ha cambiado
?>