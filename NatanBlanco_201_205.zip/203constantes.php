<?php
    define("PI", 3.1416);
    const IVA = 0.21;
    echo PI, " ", IVA;

    echo "<br>Máximo valor entero: ". PHP_INT_MAX;//Máximo valor para las variables tipo int
    echo "<br>Mínimo valor entero: ". PHP_INT_MIN;//Mínimo valor para las variables tipo int
    echo "<br>Tamaño de un entero en bytes: ". PHP_INT_SIZE ." bytes";//Tamaño de los enteros en bytes
    echo "<br>";
    echo "<br>Máximo valor float: " . PHP_FLOAT_MAX;//Máximo valor para las variables tipo float
    echo "<br>Mínimo valor float: " . PHP_FLOAT_MIN;//Mínimo valor para las variables tipo float
    ?>