<?php
//Operadores Aritméticos

//Negación
$a = 12;
$resultado = -$a;
echo "Negación: $resultado<br>";//Negación: -12

//Suma
$a = 8;
$b = 15;
$resultado = $a + $b;
echo "Suma: $resultado<br>";//Suma: 23

//Resta
$a = 50;
$b = 22;
$resultado = $a - $b;
echo "Resta: $resultado<br>";//Resta: 28

//Multiplicación
$a = 6;
$b = 7;
$resultado = $a * $b;
echo "Multiplicación: $resultado<br>";//Multiplicación: 42

//División
$a = 36;
$b = 6;
$resultado = $a / $b;
echo "División: $resultado<br>";//División: 6

//Módulo (resto)
$a = 18;
$b = 4;
$resultado = $a % $b;
echo "Módulo: $resultado<br>";//Módulo: 2

//Potencia
$a = 3;
$b = 4;
$resultado = $a ** $b;
echo "Potencia: $resultado<br>";//Potencia: 81


//Comparación

//Comparación == (valores iguales, sin importar tipo)
$a = 7;
$b = "7";
$resultado = ($a == $b);
echo "Comparación == : ".($resultado ? "true" : "false")."<br>";//True

//Comparación === (valores y tipos deben ser iguales)
$a = 7;
$b = 7;
$resultado = ($a === $b);
echo "Comparación === : ".($resultado ? "true" : "false")."<br>";//True

//Comparación != (valores diferentes)
$a = 5;
$b = 9;
$resultado = ($a != $b);
echo "Comparación != : " . ($resultado ? "true" : "false") . "<br>";//True

//Comparación !== (valores o tipos diferentes)
$a = 5;
$b = "5";
$resultado = ($a !== $b);
echo "Comparación !== : " . ($resultado ? "true" : "false") . "<br>";//True

//Comparación <
$a = 14;
$b = 25;
$resultado = ($a < $b);
echo "Comparación < : " . ($resultado ? "true" : "false") . "<br>";//True

//Comparación >
$a = 18;
$b = 12;
$resultado = ($a > $b);
echo "Comparación > : " . ($resultado ? "true" : "false") . "<br>";//True

//Comparación <=
$a = 8;
$b = 10;
$resultado = ($a <= $b);
echo "Comparación <= : " . ($resultado ? "true" : "false") . "<br>";//True

//Comparación >=
$a = 10;
$b = 10;
$resultado = ($a >= $b);
echo "Comparación >= : " . ($resultado ? "true" : "false") . "<br>";//True

//Operador nave espacial <=>
$a = 4;
$b = 4;
$resultado = $a <=> $b;//Devuelve 0 (iguales)
echo "Operador <=> : $resultado<br>";//Devuelve: 0

$a = 5;
$b = 10;
$resultado = $a <=> $b;//Devuelve -1 (menor)
echo "Operador <=> : $resultado<br>";//Devuelve: -1

$a = 12;
$b = 6;
$resultado = $a <=> $b;//Devuelve 1 (mayor)
echo "Operador <=> : $resultado<br>";//Devuelve: 1

//Operador de fusión de null ??
$a = null;
$b = "Entorno";
$c = "Servidor";
$resultado = $a ?? $b ?? $c;
echo "Operador ?? : $resultado<br>";//Entorno

$resultado = $c ?? $b;
echo "Operador ?? (c no es null): $resultado<br>";//Servidor


//Operadores Lógicos

//Operador && (y lógico)
$a = true;
$b = false;
$resultado = ($a && $b);
echo "Operador && : ".($resultado ? "true" : "false")."<br>";//False

//Operador || (o inclusivo)
$a = true;
$b = false;
$resultado = ($a || $b);
echo "Operador || : ".($resultado ? "true" : "false")."<br>";//True

//Operador XOR (o exclusivo)
$a = true;
$b = false;
$resultado = ($a XOR $b);
echo "Operador XOR : ".($resultado ? "true" : "false")."<br>";//True

//Operador NOT (! no)
$a = true;
$resultado = !$a;
echo "Operador ! : ".($resultado ? "true" : "false")."<br>";//False


//Operadores de Asignación

//Asignación
$b = 20;
$a = $b;
echo "Asignación = : $a<br>";//20

//Asignación con suma
$a = 7;
$b = 5;
$a += $b;
echo "Asignación += : $a<br>";//12

//Asignación con resta
$a = 9;
$b = 3;
$a -= $b;
echo "Asignación -= : $a<br>";//6

//Asignación con multiplicación
$a = 4;
$b = 6;
$a *= $b;
echo "Asignación *= : $a<br>";//24

//Asignación con división
$a = 20;
$b = 4;
$a /= $b;
echo "Asignación /= : $a<br>";//5

//Asignación con módulo
$a = 15;
$b = 4;
$a %= $b;
echo "Asignación %= : $a<br>";//3

//Asignación con concatenación
$a = "Entorno ";
$b = "servidor";
$a .= $b;
echo "Asignación .= : $a<br>";//Entorno servidor

//Incremento
$a = 10;
$a++;
echo "Incremento ++ : $a<br>";//11

//Decremento
$a = 10;
$a--;
echo "Decremento -- : $a<br>";//9

//Ejercicio
$b = 7;
$c = 3;
echo "Ejercicio de ejemplo: $a = $b - 2 <= $c * 2 || !($c == 3)<br>";//Ejercicio de ejemplo
echo "El resultado es true"//Resultado del ejercicio
?>
